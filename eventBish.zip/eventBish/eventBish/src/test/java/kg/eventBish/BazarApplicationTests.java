package kg.eventBish;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BazarApplicationTests {

	@Test
	void contextLoads() {
	}

}
